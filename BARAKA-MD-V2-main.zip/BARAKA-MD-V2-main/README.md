<a><img src='https://i.imgur.com/LyHic3i.gif'/></a><a><img src='https://i.imgur.com/LyHic3i.gif'/></a>


<p align="center">                                              𝐁𝐀𝐑𝐀𝐊𝐀-𝐌𝐃-𝐕2



</p>
<p align="center"> 
  <a href="https://whatsapp.com/channel/0029Vail87sIyPtQoZ2egl1h">
    <img alt=Support height="350" src="https://telegra.ph/file/cdd38b9d7c8d35e8ceee1.jpg"> 
    </p>
 
 



<a href="https://git.io/typing-svg"><img src="https://readme-typing-svg.demolab.com?font=Fira+Code&pause=1000&random=false&width=435&lines=THIS+IS+BARAKA-MD+MADE+IN+TANZANIA🇹🇿❤️🇹🇿+" alt="Typing SVG" /></a>



<a><img src='https://i.imgur.com/LyHic3i.gif'/></a><a><img src='https://i.imgur.com/LyHic3i.gif'/></a>



   <p align="left">
  <a href="https://github.com/Barakabegaa/BARAKA-MD-V2/fork">
    <img src="https://img.shields.io/github/forks/Barakabegaa/BARAKA-MD-V2?label=Fork&style=social">
  <p align="left"> 
  <a href="https://github.com/Barakabegaa/BARAKA-MD-V2/stargazers">
    <img src="https://img.shields.io/github/stars/Barakabegaa/BARAKA-MD-V2?style=social">
      

  
## _`BARAKA-MD-V2 FEATURES`_


| Feature                          | Description                                             | Available    | Version    |
| ---------------------------------| ------------------------------------------------------- | ------------ | ---------- |
| Multi-Device Support             | Operate the bot on multiple devices simultaneously      | ✅           | 3.0        |
| AI Chat Bot                      | Bot Can Reply To Questions                              | ✅           | 3.0        |
| Downloader Commands              | Download various types of content from the internet     | ✅           | 3.0        |
| Hidden NSFW Commands             | Access a range of NSFW commands hidden in the bot       | ✅           | 3.0        |
| Logo Commands                    | Generate logos using specialized commands               | ✅           | 3.0        |
| Anime Commands                   | Explore anime-related commands and features             | ✅           | 3.0        |
| Bot Cantrol Commands             | Cantrol Bot Without Opening Deploy Platform             | ✅           | 3.0        |
| Various Games                    | Enjoy a variety of games within the bot                 | ✅           | 3.0        |
| Audio/Video Editor Commands      | Edit audio and video files with bot commands            | ✅           | 3.0        |
| Auto/View once commands     | remove photo and video from lock            | ✅           | 3.0    |


## _`INSTALLATION METHODS`_

1. Fork the repo
    <br>
<a href='https://github.com/Barakabegaa/BARAKA-MD-V2/fork' target="_blank"><img alt='Fork repo' src='https://img.shields.io/badge/Fork Repo-100000?style=for-the-badge&logo=scan&logoColor=white&labelColor=black&color=black'/></a>


2. Get session id by (SCANNING QR1)
    <br>
<a href='https://baraka-md-v2-7e1ee3b2551a.herokuapp.com/qr' target="_blank"><img alt='SESSION ID' src='https://img.shields.io/badge/Session_id-100000?style=for-the-badge&logo=scan&logoColor=white&labelColor=black&color=black'/></a>


2. Get session id by (PAIRING CODE2)
    <br>
<a href='https://baraka-md-v2-7e1ee3b2551a.herokuapp.com/pair' target="_blank"><img alt='SESSION ID' src='https://img.shields.io/badge/Session_id_2-100000?style=for-the-badge&logo=scan&logoColor=white&labelColor=black&color=black'/></a>



#### DEPLOY TO HEROKU 

1. If You don't have a account in Heroku. Create a account.
    <br>
<a href='https://signup.heroku.com/' target="_blank"><img alt='Heroku' src='https://img.shields.io/badge/-Create-black?style=for-the-badge&logo=heroku&logoColor=white'/></a>


2. Now Deploy
    <br>
<a href='https://dashboard.heroku.com/new?template=https://github.com/Begajunior/BARAKA-MD-' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/-DEPLOY-black?style=for-the-badge&logo=heroku&logoColor=white'/></a>


#### DEPLOY TO REPLIT

1. If You don't have an account in Replit. Create a account.
    <br>
<a href='https://replit.com/signup' target="_blank"><img alt='Heroku' src='https://img.shields.io/badge/-Create-black?style=for-the-badge&logo=replit&logoColor=white'/></a>


2. Now Deploy
    <br>
    <a href='https://repl.it/github/salmanytofficial/XLICON-V3-MD' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/-DEPLOY-black?style=for-the-badge&logo=replit&logoColor=white'/></a>
    

#### DEPLOY TO RENDER

1. If You don't have a account in Render. Create a account.
    <br>
<a href='https://dashboard.render.com/register' target="_blank"><img alt='Render' src='https://img.shields.io/badge/CREATE-h?color=black&style=for-the-badge&logo=render' width="96.35" height="28"/></a></p>


2. Now Deploy
    <br>
<a href='https://dashboard.render.com' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/DEPLOY -h?color=black&style=for-the-badge&logo=render' width="96.35" height="28"/></a></p>


#### DEPLOY TO RAILWAY

1. If You don't have a account in Railway. Create a account.
    <br>
<a href='https://railway.app/login' target="_blank"><img alt='Railway' src='https://img.shields.io/badge/CREATE-h?color=black&style=for-the-badge&logo=railway' width="96.35" height="28"/></a></p>


2. Now Deploy
    <br>
<a href='https://railway.app/new' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/DEPLOY -h?color=black&style=for-the-badge&logo=railway' width="96.35" height="28"/></a></p>


#### DEPLOY TO OKTETO

1. If You don't have a account in Okteto. Create a account.
    <br>
<a href='https://www.okteto.com/pricing/?plan=SaaS' target="_blank"><img alt='Okteto' src='https://img.shields.io/badge/CREATE-h?color=black&style=for-the-badge&logo=opera' width="96.35" height="28"/></a></p>


2. Now Deploy
    <br>
<a href='https://cloud.okteto.com/login' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/DEPLOY -h?color=black&style=for-the-badge&logo=opera' width="96.35" height="28"/></a></p>


#### DEPLOY TO COOLIFY

1. If You don't have a account in Coolify. Create a account.
    <br>
<a href='https://app.coolify.io/register' target="_blank"><img alt='Coolify' src='https://img.shields.io/badge/CREATE-h?color=black&style=for-the-badge&logo=C' width="96.35" height="28"/></a></p>


2. Now Deploy
    <br>
<a href='https://coolify.io/' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/DEPLOY -h?color=black&style=for-the-badge&logo=C' width="96.35" height="28"/></a></p>

#### DEPLOY TO MONGENIUS

1. If You don't have a account in Mongenius. Create a account.
    <br>
<a href='https://studio.mogenius.com/user/registration' target="_blank"><img alt='Mongenius' src='https://img.shields.io/badge/CREATE-h?color=black&style=for-the-badge&logo=genius' width="96.35" height="28"/></a></p>

2. Now Deploy
    <br>
<a href='https://railway.app/new' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/DEPLOY -h?color=black&style=for-the-badge&logo=genius' width="96.35" height="28"/></a></p>

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a><a><img src='https://i.imgur.com/LyHic3i.gif'/></a>


## 🌴 *`BOT-OWNER`*
<a href="https://github.com/Barakabegaa"><img src="https://github.com/Barakabegaa.png" width="250" height="220" alt="Baraka"/></a>


## 🌴 *`MAIN-DEV`*
<a href="https://github.com/ibrahimaitech"><img src="https://github.com/ibrahimaitech.png" width="250" height="220" alt="Ibrahim"/></a>


<a><img src='https://i.imgur.com/LyHic3i.gif'/></a><a><img src='https://i.imgur.com/LyHic3i.gif'/></a>


### `𝐓𝐡𝐚𝐧𝐤𝐬 𝐓𝐨 𝐆𝐨𝐝`🙏
- Baraka-Bega
- Ibrahim-Adams
- Who Helping Me
- Who Using This Bot
- Support Me By Follow On My IG [IG Account](https://www.instagram.com/_______baraka1?igsh=MThjeDNocGYzZWZlZQ==)


<a><img src='https://i.imgur.com/LyHic3i.gif'/></a><a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
